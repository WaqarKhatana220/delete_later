# pygbag repl implement at the same time :
# - the python console in the style of browser javascript's one
# - the virtual gamepad
# - demo record/replay
# - event passthrough for pygame apps


HISTORY = []

from embed import set_ps1, set_ps2, prompt, readline
