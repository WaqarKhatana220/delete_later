from ._xterm_parser import XTermParser
